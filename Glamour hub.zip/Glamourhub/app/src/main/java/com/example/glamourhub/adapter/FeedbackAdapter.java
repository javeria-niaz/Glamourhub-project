package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Feedback;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.util.EndPoints;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class FeedbackAdapter extends BaseAdapter {
    List<Feedback> feedbackList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public FeedbackAdapter(List<Feedback> feedbackList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.feedbackList = feedbackList;
        this.onItemClick= onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return feedbackList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_feedback, parent, false);

        TextView feedback_text = convertView.findViewById(R.id.feedback_text);
        RatingBar ratingBar = convertView.findViewById(R.id.ratingBar);



        feedback_text.setText(feedbackList.get(position).getFeedback_title());
        ratingBar.setRating(Float.parseFloat(feedbackList.get(position).getRating()));



        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }
}
