package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class CartAdapter extends BaseAdapter {

    List<Subservices> subservicesList;
    Context context;
    LayoutInflater inflater;
    OnItemClick onItemClick;

    public CartAdapter(Context context, OnItemClick onItemClick, List<Subservices> subservicesList) {
        this.context = context;
        this.onItemClick = onItemClick;
        this.subservicesList = subservicesList;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return subservicesList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_cart, parent, false);
        TextView tvServiceName = convertView.findViewById(R.id.tvServiceName);
        TextView tvServicePrice = convertView.findViewById(R.id.tvServicePrice);

        tvServiceName.setText(subservicesList.get(position).getSs_title());
        tvServicePrice.setText("Rs." + subservicesList.get(position).getSs_price());


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);
            }
        });

        return convertView;
    }
}
