package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.UserAdapter;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetUserService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyStaffActivity extends AppCompatActivity {

    Button btn_AddMember;

    ListView myStaffLV;

    ProgressDialog progressDialog;
    List<Users> usersList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_staff);
        progressDialog = new ProgressDialog(MyStaffActivity.this);
        progressDialog.setMessage("please wait..");
        btn_AddMember = findViewById(R.id.btn_AddMember);
        myStaffLV = findViewById(R.id.myStaffLV);
        btn_AddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MyStaffActivity.this, AddNewMemberActivity.class));
            }
        });

        getStaffData();

/*
        CardView member1 = findViewById(R.id.member1);
        member1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MyStaffActivity.this, StaffMemberDetailActivity.class));
            }
        });

*/


    }

    private void getStaffData() {
        progressDialog.show();
        usersList.clear();

        RetrofitClient.getClient().create(GetUserService.class).getusers().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getString("user_type").equals("SM")) {
                                    usersList.add(new Users(
                                            data.getInt("user_id"),
                                            data.getString("user_name"),
                                            data.getString("user_email"),
                                            data.getString("user_cnic"),
                                            data.getString("user_contact"),
                                            data.getString("user_status"),
                                            data.getString("user_type"),
                                            data.getString("user_createdDateTime"),
                                            data.getString("user_speciality"),
                                            data.getString("user_address")
                                    ));
                                }
                            }

                            UserAdapter adapter = new UserAdapter(usersList,
                                    MyStaffActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.users = usersList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), StaffMemberDetailActivity.class));
                                    finish();

                                }
                            });
                            myStaffLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(MyStaffActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(MyStaffActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(MyStaffActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }

}