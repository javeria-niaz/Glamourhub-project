package com.example.glamourhub.services;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface UpdateBookingStatusService {


    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Update_Booking_Status_URL)
    Call<Bookings> UpdateBookingStatus(
            @Field("booking_id") int booking_id,
            @Field("booking_status") String booking_status

    );
}