package com.example.glamourhub.customer;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.CartAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.InsertBookingDetailService;
import com.example.glamourhub.services.InsertBookingService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;

import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartActivity extends AppCompatActivity {

    ListView cartLV;
    CartAdapter adapter;
    TextView tvSubTotal;
    int totalPrice = 0;
    TinyDB tinyDB;
    ProgressDialog progressDialog;
    Button btn_submit;
    Bookings bookings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        tinyDB = new TinyDB(CartActivity.this);
        progressDialog = new ProgressDialog(CartActivity.this);
        progressDialog.setMessage("please wait..");
        cartLV = findViewById(R.id.cartLV);
        tvSubTotal = findViewById(R.id.tvSubTotal);
        btn_submit = findViewById(R.id.btn_submit);
        adapter = new CartAdapter(CartActivity.this, new OnItemClick() {
            @Override
            public void onClick(int pos) {
                Constants.subservicesList.remove(pos);
                adapter.notifyDataSetChanged();
                Toast.makeText(CartActivity.this, "Item Removed From Bucket", Toast.LENGTH_SHORT).show();
                if (!Constants.subservicesList.isEmpty()) {
                    calculatePriceWihRemove(Constants.subservicesList.get(pos).getSs_price());
                }
            }
        }, Constants.subservicesList);
        cartLV.setAdapter(adapter);
        calculatePrice();

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.subservicesList.size() > 0) {
                    showCustomDialog();
                }
            }
        });


    }

    private void calculatePrice() {
        for (int i = 0; i < Constants.subservicesList.size(); i++) {
            totalPrice = totalPrice + Constants.subservicesList.get(i).getSs_price();
            tvSubTotal.setText("Rs." + totalPrice);
        }
    }

    private void calculatePriceWihRemove(int price) {
        totalPrice = totalPrice - price;
        tvSubTotal.setText("Rs." + totalPrice);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), CustomerHomeActivity.class));
        finish();
    }

    public void InsertBooking(String date, String time) {
        progressDialog.show();
        bookings = new Bookings();
        RetrofitClient.getClient().create(InsertBookingService.class).InsertBooking(
                date,
                time,
                tinyDB.getInt("USER_ID"),
                totalPrice
        ).enqueue(new Callback<Bookings>() {
            @Override
            public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    bookings = response.body();
                    if (bookings.getCode() == 200) {
                        Toast.makeText(CartActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        InsertBookingDetail(bookings.getBooking_id());
                    } else {
                        Toast.makeText(CartActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Bookings> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(CartActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void InsertBookingDetail(int b_id) {
        progressDialog.show();


        for (int i = 0; i < Constants.subservicesList.size(); i++) {
            bookings = new Bookings();
            RetrofitClient.getClient().create(InsertBookingDetailService.class).InsertBookingDetail(
                    b_id,
                    Constants.subservicesList.get(i).getSs_id()
            ).enqueue(new Callback<Bookings>() {
                @Override
                public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                    if (response.isSuccessful()) {
                        bookings = response.body();
                        if (bookings.getCode() == 200) {
                            Toast.makeText(CartActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(CartActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    }
                }

                @Override
                public void onFailure(Call<Bookings> call, Throwable t) {
                    Toast.makeText(CartActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            progressDialog.dismiss();
            Constants.subservicesList.clear();
            startActivity(new Intent(getApplicationContext(), CustomerHomeActivity.class));
            finish();

        }

    }


    public void showCustomDialog() {
        // Inflate the custom layout
        LayoutInflater inflater = LayoutInflater.from(CartActivity.this);
        View dialogView = inflater.inflate(R.layout.booking_dialog, null);

        // Build the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        // Access views inside the dialog
        TextView tvChooseBookingDate = dialogView.findViewById(R.id.tvChooseBookingDate);
        TextView tvChooseBookingTime = dialogView.findViewById(R.id.tvChooseBookingTime);
        Button btnSubmitBooking = dialogView.findViewById(R.id.btnSubmitBooking);

        tvChooseBookingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(tvChooseBookingDate);
            }
        });

        tvChooseBookingTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(tvChooseBookingTime);
            }
        });

        btnSubmitBooking.setOnClickListener(v -> {
            if (tvChooseBookingDate.getText().toString().equals("Click to Choose Booking Date")
                    || tvChooseBookingTime.getText().toString().equals("Click to Choose Booking Time")) {
                Toast.makeText(this, "Choose Date or Time", Toast.LENGTH_SHORT).show();
            } else {
                InsertBooking(tvChooseBookingDate.getText().toString(),
                        tvChooseBookingTime.getText().toString());
            }

//            dialog.dismiss();
        });

        // Show the dialog
        dialog.show();
    }


    private void showDatePickerDialog(TextView tvDate) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    // Note: month is 0-based
                    String date = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                    tvDate.setText(date);
                },
                year, month, day
        );


        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }


    private void showTimePickerDialog(TextView tvTime) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, selectedHour, selectedMinute) -> {
                    String time = String.format("%02d:%02d", selectedHour, selectedMinute);
                    tvTime.setText(time);
                },
                hour, minute, true // true = 24 hour format
        );

        timePickerDialog.show();
    }


}


