package com.example.glamourhub;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.CreateCustomerAccountService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    EditText edUsername, edEmail, edPassword, edConfirm, editContact, editCnic;
    Button btn;
    TextView textViewExistingUser;
    Users users;
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        progressDialog = new ProgressDialog(RegisterActivity.this);
        progressDialog.setMessage("please wait..");
        editContact = findViewById(R.id.editContact);
        editCnic = findViewById(R.id.editCnic);
        edUsername = findViewById(R.id.editTextRegUsername);
        edEmail = findViewById(R.id.editTextRegEmail);
        edPassword = findViewById(R.id.editTextRegPassword);
        edConfirm = findViewById(R.id.editTextConfirmPassword);
        btn = findViewById(R.id.btn_Register);
        textViewExistingUser = findViewById(R.id.textViewExistingUser);

        textViewExistingUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    createUserAccount();
                }
            }
        });

    }

    public void createUserAccount() {
        progressDialog.show();
        users = new Users();

        RetrofitClient.getClient().create(CreateCustomerAccountService.class).createAccount(
                edUsername.getText().toString(),
                edEmail.getText().toString(),
                edPassword.getText().toString(),
                editCnic.getText().toString(),
                editContact.getText().toString(), "A", "C"
        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    users = response.body();

                    if (users.getCode() == 200) {
                        Toast.makeText(RegisterActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                    } else {
                        Toast.makeText(RegisterActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(RegisterActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    public boolean validation() {
        boolean isvalid = true;
        if (edUsername.getText().toString().isEmpty()) {
            edUsername.setError("fill this field");
            isvalid = false;
        }

        if (edEmail.getText().toString().isEmpty()) {
            edEmail.setError("fill this field");
            isvalid = false;
        }
        if (edPassword.getText().toString().isEmpty()) {
            edPassword.setError("fill this field");
            isvalid = false;
        }

        if (edPassword.getText().toString().length() < 6) {
            edPassword.setError("Password too Short");
            isvalid = false;
        }

        if (edConfirm.getText().toString().isEmpty()) {
            edConfirm.setError("fill this field");
            isvalid = false;
        }

        if (editContact.getText().toString().isEmpty()) {
            editContact.setError("fill this field");
            isvalid = false;
        }
    

        if (editCnic.getText().toString().isEmpty()) {
            editCnic.setError("fill this field");
            isvalid = false;
        }

        return isvalid;
    }
}