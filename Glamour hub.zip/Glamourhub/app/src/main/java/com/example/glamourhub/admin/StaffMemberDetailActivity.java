package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.DeleteStaffMemberService;
import com.example.glamourhub.services.UpdateUserStatus;
import com.example.glamourhub.util.Constants;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StaffMemberDetailActivity extends AppCompatActivity {

    TextView Name, Email, Contact, Cnic, Address, tvSpecialized;
    RadioButton Active, NotActive;

    Users users;
    ProgressDialog progressDialog;

    Button btn_Update, btn_Delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_member_detail);
        progressDialog = new ProgressDialog(StaffMemberDetailActivity.this);
        progressDialog.setTitle("please wait..");
        Name = findViewById(R.id.Name);
        Email = findViewById(R.id.Email);
        Contact = findViewById(R.id.Contact);
        Active = findViewById(R.id.Active);
        Cnic = findViewById(R.id.Cnic);
        NotActive = findViewById(R.id.NotActive);
        Address = findViewById(R.id.Address);
        tvSpecialized = findViewById(R.id.tvSpecialized);
        btn_Update = findViewById(R.id.btn_Update);
        btn_Delete = findViewById(R.id.btn_Delete);

        tvSpecialized.setText(Constants.users.getUser_speciality());
        Name.setText(Constants.users.getUser_name());
        Email.setText(Constants.users.getUser_email());
        Contact.setText(Constants.users.getUser_contact());
        Cnic.setText(Constants.users.getUser_cnic());

        Address.setText(Constants.users.getUser_address());

        if (Constants.users.getUser_status().equals("A")) {
            Active.setChecked(true);
            NotActive.setChecked(false);
        } else if (Constants.users.getUser_status().equals("B")) {
            Active.setChecked(false);
            NotActive.setChecked(true);
        }

        btn_Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Active.isChecked()) {
                    UpdateUserStatus("A");
                } else if (NotActive.isChecked()) {
                    UpdateUserStatus("B");
                }
            }
        });

        btn_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteStaffMember();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
        finish();

    }

    public void UpdateUserStatus(String _status) {
        progressDialog.show();
        users = new Users();
        RetrofitClient.getClient().create(UpdateUserStatus.class).UpdateStatus(
                Constants.users.getUser_id(), _status
        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    users = response.body();
                    if (!users.isError()) {
                        Toast.makeText(StaffMemberDetailActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
                        finish();
                    } else {
                        Toast.makeText(StaffMemberDetailActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(StaffMemberDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }


    public void DeleteStaffMember() {
        progressDialog.show();
        users = new Users();


        RetrofitClient.getClient().create(DeleteStaffMemberService.class).DeleteStaffMember(Constants.users.getUser_id()).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    users = response.body();
                    if (users.getCode() == 200) {
                        Toast.makeText(StaffMemberDetailActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
                        finish();
                    } else {
                        Toast.makeText(StaffMemberDetailActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(StaffMemberDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}