package com.example.glamourhub.admin;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.AddSubService;
import com.example.glamourhub.util.Constants;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddProductActivity extends AppCompatActivity {

    ImageView imageView;

    EditText editTextTitle, Description, Price, edtDuration;
    Button btn_submit;
    ProgressDialog progressDialog;

    Subservices subservices;

    Uri imageUri;
    File file;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        imageView = findViewById(R.id.imageView);
        editTextTitle = findViewById(R.id.editTextTitle);
        progressDialog = new ProgressDialog(AddProductActivity.this);
        progressDialog.setMessage("please wait..");
        Description = findViewById(R.id.Description);
        Price = findViewById(R.id.Price);
        edtDuration = findViewById(R.id.duration);
        btn_submit = findViewById(R.id.btn_submit);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Pick Image"), 1002);
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    AddNewSubService();
                }
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 1002) {
            imageView.setImageURI(data.getData());
            imageUri = data.getData();
        }
    }

    public void AddNewSubService() {
        progressDialog.show();
        subservices = new Subservices();

        if (imageUri == null) {
            Toast.makeText(this, "no image", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        } else {
            file = new File(getRealPathFromURI(imageUri));
            //creating request body for file
            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            //creating request body for name
            RequestBody title = RequestBody.create(MediaType.parse("text/plain"), editTextTitle.getText().toString());
            RequestBody description = RequestBody.create(MediaType.parse("text/plain"), Description.getText().toString());
            RequestBody price = RequestBody.create(MediaType.parse("text/plain"), Price.getText().toString());
            RequestBody duration = RequestBody.create(MediaType.parse("text/plain"), edtDuration.getText().toString());
            MultipartBody.Part body = MultipartBody.Part.createFormData("filetoupload", file.getName(), requestFile);
            RequestBody serviceID = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(Constants.services.getService_id()));

            RetrofitClient.getClient().create(AddSubService.class).AddSubServices(title, description, price, duration, body, serviceID).enqueue(new Callback<Subservices>() {
                @Override
                public void onResponse(Call<Subservices> call, Response<Subservices> response) {
                    if (response.isSuccessful()) {
                        subservices = response.body();
                        if (subservices.getCode() == 200) {
                            Toast.makeText(AddProductActivity.this, subservices.getMessage(), Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), OurServiceActivity.class));
                            finish();
                        } else {
                            Toast.makeText(AddProductActivity.this, subservices.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Subservices> call, Throwable t) {
                    progressDialog.dismiss();
                    Toast.makeText(AddProductActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }

    public boolean validation() {
        boolean isvalid = true;
        if (editTextTitle.getText().toString().isEmpty()) {
            editTextTitle.setError("fill this field");
            isvalid = false;
        }
        if (Description.getText().toString().isEmpty()) {
            Description.setError("fill this field");
            isvalid = false;
        }
        if (Price.getText().toString().isEmpty()) {
            Price.setError("fill this field");
            isvalid = false;
        }
        if (edtDuration.getText().toString().isEmpty()) {
            edtDuration.setError("fill this field");
            isvalid = false;
        }
        return isvalid;
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(this, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }


}