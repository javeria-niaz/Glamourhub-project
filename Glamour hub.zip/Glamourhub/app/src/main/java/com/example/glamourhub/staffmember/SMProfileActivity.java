package com.example.glamourhub.staffmember;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.UpdateProfileService;
import com.example.glamourhub.util.TinyDB;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SMProfileActivity extends AppCompatActivity {

    EditText ETName, ETEmail, ETContact, EtCnic;
    Button changePassword, update;
    TextView ETSpeciality,ETFees;
    ProgressDialog progressDialog;
    TinyDB tinyDB;
    Users usersData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smprofile);
        progressDialog = new ProgressDialog(SMProfileActivity.this);
        progressDialog.setMessage("please wait..");
        tinyDB = new TinyDB(SMProfileActivity.this);
        ETName = findViewById(R.id.ETName);
        ETEmail = findViewById(R.id.ETEmail);
        ETContact = findViewById(R.id.ETContact);
        EtCnic = findViewById(R.id.EtCnic);
        ETSpeciality = findViewById(R.id.ETSpeciality);

        ETName.setText(tinyDB.getString("USER_NAME"));
        ETEmail.setText(tinyDB.getString("USER_EMAIL"));
        ETContact.setText(tinyDB.getString("USER_CONTACT"));
        EtCnic.setText(tinyDB.getString("USER_CNIC"));
        ETSpeciality.setText(tinyDB.getString("USER_SPECIALIZATION"));

        update = findViewById(R.id.update);
        changePassword = findViewById(R.id.changePassword);
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SMProfileActivity.this, ChangePasswordActivity.class));
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    UpdateProfile();
                }
            }
        });
    }

    public void UpdateProfile() {
        progressDialog.show();
        usersData = new Users();
        RetrofitClient.getClient().create(UpdateProfileService.class).UpdateProfile(
                tinyDB.getInt("USER_ID"),
                ETName.getText().toString(),
                EtCnic.getText().toString(),
                ETContact.getText().toString(),
                ETEmail.getText().toString()

        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    usersData = response.body();
                    if (usersData.getCode() == 200) {
                        tinyDB.putString("USER_NAME", ETName.getText().toString());
                        tinyDB.putString("USER_CONTACT", ETContact.getText().toString());
                        tinyDB.putString("USER_CNIC", EtCnic.getText().toString());
                        Toast.makeText(SMProfileActivity.this, usersData.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), StaffHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(SMProfileActivity.this, usersData.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SMProfileActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    public boolean validation() {
        boolean isvalid = true;
        if (ETName.getText().toString().isEmpty()) {
            ETName.setError("fill this field");
            isvalid = false;
        }
        if (ETEmail.getText().toString().isEmpty()) {
            ETEmail.setError("fill this field");
            isvalid = false;
        }
        if (ETContact.getText().toString().isEmpty()) {
            ETContact.setError("fill this field");
            isvalid = false;
        }
        if (EtCnic.getText().toString().isEmpty()) {
            EtCnic.setError("fill this field");
            isvalid = false;
        }
        return isvalid;
    }

}