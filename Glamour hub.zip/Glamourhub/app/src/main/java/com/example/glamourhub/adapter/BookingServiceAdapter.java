package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetUserService;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookingServiceAdapter extends BaseAdapter {

    List<Subservices> subservicesList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public BookingServiceAdapter(List<Subservices> subservicesList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.subservicesList = subservicesList;
        this.onItemClick = onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return subservicesList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_booking_service, parent, false);

        TextView servicename = convertView.findViewById(R.id.servicename);
        TextView duration = convertView.findViewById(R.id.duration);
        TextView tvAssignName = convertView.findViewById(R.id.tvAssignName);

        servicename.setText(subservicesList.get(position).getSs_title());
        duration.setText(String.valueOf(subservicesList.get(position).getSs_price()));
        tvAssignName.setText(getStaffData(subservicesList.get(position).getFk_staff_id()));

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }


    String name = "";

    private String getStaffData(int id) {
        RetrofitClient.getClient().create(GetUserService.class).getusers().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getInt("user_id") == id) {
                                    name = data.getString("user_name");
                                    notifyDataSetChanged();
                                    break;
                                }
                            }

                        } catch (Exception exception) {
                            Toast.makeText(context, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(context, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

        return name;

    }

}
