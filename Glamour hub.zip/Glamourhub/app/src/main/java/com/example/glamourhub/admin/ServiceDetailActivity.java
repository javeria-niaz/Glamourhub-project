package com.example.glamourhub.admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.DeleteService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ServiceDetailActivity extends AppCompatActivity {

    Button btn_ViewProduct, btn_AddProduct, btn_Delete;
    ImageView imageView;
    EditText editTextTitle;
    ProgressDialog progressDialog;
    Services servicesData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_detail);
        progressDialog = new ProgressDialog(ServiceDetailActivity.this);
        progressDialog.setMessage("please wait..");
        btn_ViewProduct = findViewById(R.id.btn_ViewProduct);
        btn_AddProduct = findViewById(R.id.btn_AddProduct);
        btn_Delete = findViewById(R.id.btn_Delete);
        imageView = findViewById(R.id.imageView);
        editTextTitle = findViewById(R.id.editTextTitle);

        editTextTitle.setText(Constants.services.getService_title());
        Glide.with(ServiceDetailActivity.this).load(EndPoints.IMAGE_URL + Constants.services.getService_image())
                .into(imageView);

        btn_ViewProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ServiceDetailActivity.this, ViewProductActivity.class));
            }
        });

        btn_AddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ServiceDetailActivity.this, AddProductActivity.class));
            }
        });


        btn_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteService();
            }
        });

    }

    public void DeleteService() {
        progressDialog.show();
        servicesData = new Services();


        RetrofitClient.getClient().create(DeleteService.class).DeleteService(Constants.services.getService_id()).enqueue(new Callback<Services>() {
            @Override
            public void onResponse(Call<Services> call, Response<Services> response) {
                if (response.isSuccessful()) {
                    servicesData = response.body();
                    if (servicesData.getCode() == 200) {
                        Toast.makeText(ServiceDetailActivity.this, servicesData.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), OurServiceActivity.class));
                        finish();
                    } else {
                        Toast.makeText(ServiceDetailActivity.this, servicesData.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Services> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(ServiceDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

}