package com.example.glamourhub.services;

import com.example.glamourhub.util.EndPoints;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface GetSubService {

    @Headers("Accept: application/json")
    @GET(EndPoints.Get_Sub_Services_URL)
    Call<JsonObject> getsubservices();
}
