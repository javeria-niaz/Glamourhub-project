package com.example.glamourhub.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Services {
    @SerializedName("service_id ")
    @Expose
    private int service_id;

    @SerializedName("service_title ")
    @Expose
    private String service_title;

    @SerializedName("service_image ")
    @Expose
    private String service_image;

    @SerializedName("service_status ")
    @Expose
    private String service_status;

    @SerializedName("code")
    @Expose
    private int code;

    @SerializedName("error")
    @Expose
    private boolean error;

    @SerializedName("message")
    @Expose
    private String message;

    public Services() {
    }

    public Services(int service_id, String service_title, String service_image, String service_status) {
        this.service_id = service_id;
        this.service_image = service_image;
        this.service_status = service_status;
        this.service_title = service_title;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getService_id() {
        return service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public String getService_image() {
        return service_image;
    }

    public void setService_image(String service_image) {
        this.service_image = service_image;
    }

    public String getService_status() {
        return service_status;
    }

    public void setService_status(String service_status) {
        this.service_status = service_status;
    }

    public String getService_title() {
        return service_title;
    }

    public void setService_title(String service_title) {
        this.service_title = service_title;
    }

}
