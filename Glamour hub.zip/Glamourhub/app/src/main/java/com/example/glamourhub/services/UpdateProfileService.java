package com.example.glamourhub.services;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface UpdateProfileService {
    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Update_Profile_URL)
    Call<Users> UpdateProfile(
            @Field("user_id") int user_id,
            @Field("user_name") String user_name,
            @Field("user_cnic") String user_cnic,
            @Field("user_contact") String user_contact,
            @Field("user_email") String user_email

    );
}
