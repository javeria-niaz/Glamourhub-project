package com.example.glamourhub.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.EndPoints;

public class CustomerProductDetailActivity extends AppCompatActivity {

    TextView EditTitle, Description, Price, duration;
    Button brnCreateBooking;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_product_detail);
        EditTitle = findViewById(R.id.Title);
        Description = findViewById(R.id.Description);
        Price = findViewById(R.id.Price);
        duration = findViewById(R.id.duration);
        brnCreateBooking = findViewById(R.id.brnCreateBooking);
        imageView = findViewById(R.id.imageView);

        EditTitle.setText(Constants.subservices.getSs_title());
        Description.setText(Constants.subservices.getSs_description());
        Price.setText(String.valueOf(Constants.subservices.getSs_price()));
        duration.setText(String.valueOf(Constants.subservices.getSs_duration()));
        Glide.with(CustomerProductDetailActivity.this).load(EndPoints.IMAGE_URL + Constants.subservices.getSs_image())
                .into(imageView);

        brnCreateBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!hasData(Constants.subservices)) {
                    Toast.makeText(CustomerProductDetailActivity.this, "Product Added", Toast.LENGTH_SHORT).show();
                    Constants.subservicesList.add(Constants.subservices);
                    startActivity(new Intent(getApplicationContext(), CustomerHomeActivity.class));
                    finish();
                }else{
                    Toast.makeText(CustomerProductDetailActivity.this, "Already in Bucket", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    public boolean hasData(Subservices subservices) {
        boolean isPresent = false;
        for (int i = 0; i < Constants.subservicesList.size(); i++) {
            if (Constants.subservicesList.get(i).getFk_service_id() == subservices.getFk_service_id()) {
                isPresent = true;
            }
        }
        return isPresent;
    }


}