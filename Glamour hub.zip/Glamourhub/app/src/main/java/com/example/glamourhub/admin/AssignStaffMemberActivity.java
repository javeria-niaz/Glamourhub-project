package com.example.glamourhub.admin;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.AlarmReceiver;
import com.example.glamourhub.R;
import com.example.glamourhub.adapter.UserAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetUserService;
import com.example.glamourhub.services.UpdateBookingService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssignStaffMemberActivity extends AppCompatActivity {

    ListView myStaffLV;
    ProgressDialog progressDialog;
    List<Users> usersList = new ArrayList<>();

    Bookings bookings;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_staff_member);
        progressDialog = new ProgressDialog(AssignStaffMemberActivity.this);
        progressDialog.setMessage("please wait..");
        myStaffLV = findViewById(R.id.myStaffLV);
        getStaffData();
    }

    private void getStaffData() {
        progressDialog.show();
        usersList.clear();

        RetrofitClient.getClient().create(GetUserService.class).getusers().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getString("user_type").equals("SM")
                                        && data.getString("user_speciality").equals(Constants.subservices.getService_title())) {
                                    usersList.add(new Users(
                                            data.getInt("user_id"),
                                            data.getString("user_name"),
                                            data.getString("user_email"),
                                            data.getString("user_cnic"),
                                            data.getString("user_contact"),
                                            data.getString("user_status"),
                                            data.getString("user_type"),
                                            data.getString("user_createdDateTime"),
                                            data.getString("user_speciality"),
                                            data.getString("user_address")
                                    ));
                                }
                            }

                            UserAdapter adapter = new UserAdapter(usersList,
                                    AssignStaffMemberActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    updateBooking(usersList.get(pos).getUser_id());
                                }
                            });
                            myStaffLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(AssignStaffMemberActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(AssignStaffMemberActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(AssignStaffMemberActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }

    public void updateBooking(int staffID) {
        progressDialog.show();
        bookings = new Bookings();

        RetrofitClient.getClient().create(UpdateBookingService.class).UpdateBooking(
                Constants.bookings.getBooking_id(),
                staffID, Constants.subservices.getSs_id(), "A"
        ).enqueue(new Callback<Bookings>() {
            @Override
            public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    bookings = response.body();
                    if (bookings.getCode() == 200) {
                        Toast.makeText(AssignStaffMemberActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        setAlarmFromDateTime(AssignStaffMemberActivity.this,
                                Constants.bookings.getBooking_date(),
                                Constants.bookings.getBooking_time()); // Set alarm for 2:30 PM on April 19, 2025

                        startActivity(new Intent(getApplicationContext(), MyBookingActivity.class));
                        finish();
                    } else {
                        Toast.makeText(AssignStaffMemberActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<Bookings> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AssignStaffMemberActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setAlarmFromDateTime(Context context, String dateStr, String timeStr) {
        try {
            // Combine date and time into one string
            String dateTimeStr = dateStr + " " + timeStr; // e.g., "2025-04-19 14:30"

            // Define the format
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

            // Parse to Date object
            Date date = sdf.parse(dateTimeStr);
            if (date == null) return;

            // Convert to Calendar
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            // Call alarm setter
            setAlarm(context, calendar);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ScheduleExactAlarm")
    public void setAlarm(Context context, Calendar calendar) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, Constants.bookings.getBooking_id(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

    }


}