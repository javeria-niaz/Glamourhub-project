package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.UpdateProfileService;
import com.example.glamourhub.staffmember.ChangePasswordActivity;
import com.example.glamourhub.util.TinyDB;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerProfileActivity extends AppCompatActivity {

    EditText EditName, EditEmail, editContact, editCNIC;

    Button changePassword, update;
    TinyDB tinyDB;
    ProgressDialog progressDialog;
    Users users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_profile);
        progressDialog = new ProgressDialog(CustomerProfileActivity.this);
        progressDialog.setMessage("please wait..");
        tinyDB = new TinyDB(CustomerProfileActivity.this);
        changePassword = findViewById(R.id.changePassword);
        EditName = findViewById(R.id.EditName);
        EditEmail = findViewById(R.id.EditEmail);
        editContact = findViewById(R.id.editContact);
        editCNIC = findViewById(R.id.editCNIC);
        update = findViewById(R.id.update);

        EditName.setText(tinyDB.getString("USER_NAME"));
        EditEmail.setText(tinyDB.getString("USER_EMAIL"));
        editContact.setText(tinyDB.getString("USER_CONTACT"));
        editCNIC.setText(tinyDB.getString("USER_CNIC"));


        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CustomerProfileActivity.this, ChangePasswordActivity.class));
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    UpdateProfileData();
                }
            }
        });

    }

    public void UpdateProfileData() {
        progressDialog.show();
        users = new Users();
        RetrofitClient.getClient().create(UpdateProfileService.class).UpdateProfile(
                tinyDB.getInt("USER_ID"),
                EditName.getText().toString(),
                editCNIC.getText().toString(),
                editContact.getText().toString(),
                EditEmail.getText().toString()

        ).enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, Response<Users> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    users = response.body();
                    if (users.getCode() == 200) {
                        Toast.makeText(CustomerProfileActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                        tinyDB.putString("USER_NAME", EditName.getText().toString());
                        tinyDB.putString("USER_CONTACT", editContact.getText().toString());
                        tinyDB.putString("USER_CNIC", editCNIC.getText().toString());

                        startActivity(new Intent(getApplicationContext(), CustomerHomeActivity.class));
                        finish();
                    } else {
                        Toast.makeText(CustomerProfileActivity.this, users.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(CustomerProfileActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public boolean validation() {
        boolean isvalid = true;
        if (EditName.getText().toString().isEmpty()) {
            EditName.setError("fill this field");
            isvalid = false;
        }
        if (EditEmail.getText().toString().isEmpty()) {
            EditEmail.setError("fill this field");
            isvalid = false;
        }
        if (editContact.getText().toString().isEmpty()) {
            editContact.setError("fill this field");
            isvalid = false;
        }
        if (editCNIC.getText().toString().isEmpty()) {
            editCNIC.setError("fill this field");
            isvalid = false;
        }

        return isvalid;
    }
}