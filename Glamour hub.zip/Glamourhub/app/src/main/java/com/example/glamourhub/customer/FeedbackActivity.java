package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.glamourhub.R;
import com.example.glamourhub.admin.AddNewMemberActivity;
import com.example.glamourhub.admin.MyStaffActivity;
import com.example.glamourhub.model.Feedback;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.InsertFeedbackService;
import com.example.glamourhub.services.InsertStaffMemberService;
import com.example.glamourhub.util.Constants;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FeedbackActivity extends AppCompatActivity {

    RatingBar ratingBar;
    EditText feedback_text;
    Button submit_feedback;
    ProgressDialog progressDialog;
    Feedback feedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_feedback);
        progressDialog = new ProgressDialog(FeedbackActivity.this);
        progressDialog.setMessage("please wait..");

        ratingBar = findViewById(R.id.ratingBar);
        feedback_text = findViewById(R.id.feedback_text);
        submit_feedback = findViewById(R.id.submit_feedback);

        submit_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (validation()) {
                    AddFeedback();
                }
            }
        });

    }
    public void AddFeedback() {
        progressDialog.show();
        feedback = new Feedback();

        RetrofitClient.getClient().create(InsertFeedbackService.class).InsertFeedback(
                feedback_text.getText().toString(),
                3,
                String.valueOf(ratingBar.getRating())

        ).enqueue(new Callback<Feedback>() {
            @Override
            public void onResponse(Call<Feedback> call, Response<Feedback> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    feedback = response.body();
                    if (feedback.getCode() == 200) {
                        Toast.makeText(FeedbackActivity.this, feedback.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyStaffActivity.class));
                        finish();
                    } else {
                        Toast.makeText(FeedbackActivity.this, feedback.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Feedback> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(FeedbackActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public boolean validation() {
        boolean isvalid = true;
        if (feedback_text.getText().toString().isEmpty()) {
            feedback_text.setError("fill this field");
            isvalid = false;
        }
        if (ratingBar.getRating() == 0.0f) {
            Toast.makeText(getApplicationContext(), "Please provide a rating", Toast.LENGTH_SHORT).show();
            isvalid = false;
        }
        return isvalid;
    }


}