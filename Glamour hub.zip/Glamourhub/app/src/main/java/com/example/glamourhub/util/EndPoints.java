package com.example.glamourhub.util;

public class EndPoints {
    public static final String BASE_URL = "http://192.168.1.123/GlamourHubAPI/";
    public static final String IMAGE_URL = "http://192.168.1.123/GlamourHubAPI/image/";
    public static final String CREATE_CUSTOMER_URL = BASE_URL + "api/CreateCustomerAPI.php";
    public static final String Login_URL = BASE_URL + "api/LoginAPI.php";
    public static final String Add_Service_URL = BASE_URL + "api/InsertServiceAPI.php";
    public static final String Add_Sub_Service_URL = BASE_URL + "api/InsertSubServicesAPI.php";
    public static final String Get_Users_URL = BASE_URL + "api/GetUsersAPI.php";
    public static final String Insert_StaffMember_URL = BASE_URL + "api/InsertStaffMemberAPI.php";
    public static final String Update_User_Status_URL = BASE_URL + "api/UpdateUserStatusAPI.php";
    public static final String Get_Services_URL = BASE_URL + "api/GetServiceAPI.php";
    public static final String Get_Sub_Services_URL = BASE_URL + "api/GetSubServiceAPI.php";
    public static final String Delete_Service_URL = BASE_URL + "api/DeleteServiceAPI.php";
    public static final String Delete_Sub_Service_URL = BASE_URL + "api/DeleteSubServiceAPI.php";
    public static final String Delete_Staff_Member_URL = BASE_URL + "api/DeleteStaffMemberAPI.php";
    public static final String Insert_Booking_URL = BASE_URL + "api/InsertBookingAPI.php";
    public static final String Insert_Booking_Detail_URL = BASE_URL + "api/InsertBookingDetailAPI.php";
    public static final String Get_Booking_URL = BASE_URL + "api/GetBookingAPI.php";
    public static final String Get_STAFF_Booking_URL = BASE_URL + "api/GetStaffBookingAPI.php";
    public static final String Get_Booking_SERVICES_URL = BASE_URL + "api/GetBookingServiceAPI.php";
    public static final String Update_Booking_URL = BASE_URL + "api/UpdateBookingAPI.php";
    public static final String Update_Booking_Status_URL = BASE_URL + "api/UpdateBookingStatusAPI.php";
    public static final String Update_Profile_URL = BASE_URL + "api/UpdateProfileAPI.php";
    public static final String Insert_Feedback_URL = BASE_URL + "api/InsertFeedBackAPI.php";
    public static final String Get_Feedback_URL = BASE_URL + "api/GetFeedbackAPI.php";
    public static final String CHANGE_PASSWORD_URL = BASE_URL + "api/ChangePasswordAPI.php";
    public static final String Update_Sub_Service_URL = BASE_URL + "api/UpdateSubServiceAPI.php";
    public static final String Update_Sub_Service_IMAGE_URL = BASE_URL + "api/UpdateSubServiceImageAPI.php";
    public static final String Get_Notification_URL = BASE_URL + "api/GetNotificationAPI.php";


}
