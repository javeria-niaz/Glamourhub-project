package com.example.glamourhub.admin;

import static com.example.glamourhub.customer.BookingHistoryDetailActivity.generateRandomString;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.BookingServiceAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetBookingServices;
import com.example.glamourhub.services.GetUserService;
import com.example.glamourhub.services.UpdateBookingStatusService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookingDetailActivity extends AppCompatActivity {
    TextView bookingNo, bookingDate, bookingPrice, customerName, clientNo;
    Button btn_Complete, btn_cancel;
    ListView SubServicesLV;
    Bookings bookings;
    LinearLayout buttonsLL;
    ProgressDialog progressDialog;
    List<Subservices> subServicesList = new ArrayList<>();
    List<Users> usersList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_detail);
        progressDialog = new ProgressDialog(BookingDetailActivity.this);
        progressDialog.setMessage("please wait..");
        buttonsLL = findViewById(R.id.buttonsLL);
        SubServicesLV = findViewById(R.id.SubServicesLV);
        bookingNo = findViewById(R.id.bookingNo);
        bookingDate = findViewById(R.id.bookingDate);
        bookingPrice = findViewById(R.id.bookingPrice);
        customerName = findViewById(R.id.customerName);
        clientNo = findViewById(R.id.clientNo);
        btn_Complete = findViewById(R.id.btn_Complete);
        btn_cancel = findViewById(R.id.btn_cancel);


        bookingNo.setText(generateRandomString(8));

        bookingPrice.setText(String.valueOf(Constants.bookings.getBooking_total_price()));
        bookingDate.setText(Constants.bookings.getBooking_date() + " /" + Constants.bookings.getBooking_time());

        if (Constants.bookings.getBooking_status().equals("R") || Constants.bookings.getBooking_status().equals("CMP")) {
            buttonsLL.setVisibility(View.GONE);
        } else {
            buttonsLL.setVisibility(View.VISIBLE);
        }

        btn_Complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBookingStatus();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelBooking();
            }
        });


        getStaffData();

        getSubServiceData();
    }

    private void getSubServiceData() {
        progressDialog.show();
        subServicesList.clear();

        RetrofitClient.getClient().create(GetBookingServices.class).getServices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getInt("fk_booking_id") == Constants.bookings.getBooking_id()) {

                                    subServicesList.add(new Subservices(
                                            data.getInt("bd_id"),
                                            data.getInt("fk_booking_id"),
                                            data.getInt("fk_subservice_id"),
                                            data.getInt("fk_staff_id"),
                                            data.getInt("ss_id"),
                                            data.getString("ss_title"),
                                            data.getString("ss_image"),
                                            data.getInt("ss_price"),
                                            data.getInt("service_id"),
                                            data.getString("service_title")
                                    ));

                                }


                                BookingServiceAdapter adapter = new BookingServiceAdapter(subServicesList,
                                        BookingDetailActivity.this, new OnItemClick() {
                                    @Override
                                    public void onClick(int pos) {
                                        Constants.subservices = subServicesList.get(pos);
                                        startActivity(new Intent(getApplicationContext(), AssignStaffMemberActivity.class));
                                        finish();

                                    }
                                });
                                SubServicesLV.setAdapter(adapter);


                            }


                        } catch (Exception exception) {
                            Toast.makeText(BookingDetailActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(BookingDetailActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(BookingDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    private void getStaffData() {
        progressDialog.show();
        usersList.clear();

        RetrofitClient.getClient().create(GetUserService.class).getusers().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (Constants.bookings.getFk_user_id() == data.getInt("user_id")) {
                                    customerName.setText(data.getString("user_name"));
                                    clientNo.setText(data.getString("user_contact"));
                                    break;
                                }
                            }


                        } catch (Exception exception) {
                            Toast.makeText(BookingDetailActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(BookingDetailActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(BookingDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void cancelBooking() {
        progressDialog.show();
        bookings = new Bookings();


        RetrofitClient.getClient().create(UpdateBookingStatusService.class).UpdateBookingStatus(
                Constants.bookings.getBooking_id(), "R"
        ).enqueue(new Callback<Bookings>() {
            @Override
            public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    bookings = response.body();
                    if (bookings.getCode() == 200) {
                        Toast.makeText(BookingDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyBookingActivity.class));
                        finish();
                    } else {
                        Toast.makeText(BookingDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<Bookings> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(BookingDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void updateBookingStatus() {
        progressDialog.show();
        bookings = new Bookings();


        RetrofitClient.getClient().create(UpdateBookingStatusService.class).UpdateBookingStatus(
                Constants.bookings.getBooking_id(), "CMP"
        ).enqueue(new Callback<Bookings>() {
            @Override
            public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    bookings = response.body();
                    if (bookings.getCode() == 200) {
                        Toast.makeText(BookingDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MyBookingActivity.class));
                        finish();
                    } else {
                        Toast.makeText(BookingDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<Bookings> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(BookingDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


}