package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.R;
import com.example.glamourhub.adapter.BookingServiceAdapter;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetBookingServices;
import com.example.glamourhub.services.UpdateBookingStatusService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookingHistoryDetailActivity extends AppCompatActivity {

    TextView bookingNo, BookingDate, bookingPrice;
    Button btn_cancel;

    ListView SubServicesLV;
    Bookings bookings;

    ProgressDialog progressDialog;
    List<Subservices> subServicesList = new ArrayList<>();
    List<Bookings> BookingsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_booking_history_detail);
        progressDialog = new ProgressDialog(BookingHistoryDetailActivity.this);
        progressDialog.setMessage("please wait..");
        SubServicesLV = findViewById(R.id.SubServicesLV);

        bookingNo = findViewById(R.id.bookingNo);
        btn_cancel = findViewById(R.id.btn_cancel);

        BookingDate = findViewById(R.id.BookingDate);
        bookingPrice = findViewById(R.id.bookingPrice);

        bookingPrice.setText(String.valueOf(Constants.bookings.getBooking_total_price()));
        BookingDate.setText(Constants.bookings.getBooking_date() + " /" + Constants.bookings.getBooking_time());

        bookingNo.setText(generateRandomString(8));

        if (Constants.bookings.getBooking_status().equals("P")) {
            btn_cancel.setVisibility(View.VISIBLE);
        } else {
            btn_cancel.setVisibility(View.GONE);
        }

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBookingStatus();
            }
        });

        getSubServiceData();

    }

    private void getSubServiceData() {
        progressDialog.show();
        subServicesList.clear();

        RetrofitClient.getClient().create(GetBookingServices.class).getServices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getInt("fk_booking_id") == Constants.bookings.getBooking_id()) {
                                    subServicesList.add(new Subservices(
                                            data.getInt("bd_id"),
                                            data.getInt("fk_booking_id"),
                                            data.getInt("fk_subservice_id"),
                                            data.getInt("fk_staff_id"),
                                            data.getInt("ss_id"),
                                            data.getString("ss_title"),
                                            data.getString("ss_image"),
                                            data.getInt("ss_price"),
                                            data.getInt("service_id"),
                                            data.getString("service_title")
                                    ));

                                }


                                BookingServiceAdapter adapter = new BookingServiceAdapter(subServicesList,
                                        BookingHistoryDetailActivity.this, new OnItemClick() {
                                    @Override
                                    public void onClick(int pos) {
                                        Constants.subservices = subServicesList.get(pos);
                                     /*   startActivity(new Intent(getApplicationContext(), AssignStaffMemberActivity.class));
                                        finish();*/

                                    }
                                });
                                SubServicesLV.setAdapter(adapter);


                            }


                        } catch (Exception exception) {
                            Toast.makeText(BookingHistoryDetailActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(BookingHistoryDetailActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(BookingHistoryDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    private void updateBookingStatus() {
        progressDialog.show();
        bookings = new Bookings();


        RetrofitClient.getClient().create(UpdateBookingStatusService.class).UpdateBookingStatus(
                Constants.bookings.getBooking_id(), "C"
        ).enqueue(new Callback<Bookings>() {
            @Override
            public void onResponse(Call<Bookings> call, Response<Bookings> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    bookings = response.body();
                    if (bookings.getCode() == 200) {
                        Toast.makeText(BookingHistoryDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), BookingHistoryActivity.class));
                        finish();
                    } else {
                        Toast.makeText(BookingHistoryDetailActivity.this, bookings.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<Bookings> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(BookingHistoryDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final SecureRandom random = new SecureRandom();

    public static String generateRandomString(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(randomIndex));
        }
        return sb.toString();
    }


}