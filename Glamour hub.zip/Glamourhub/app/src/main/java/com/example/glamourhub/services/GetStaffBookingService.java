package com.example.glamourhub.services;

import com.example.glamourhub.util.EndPoints;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface GetStaffBookingService {
    @Headers("Accept: application/json")
    @GET(EndPoints.Get_STAFF_Booking_URL)
    Call<JsonObject> getbookings();
}
