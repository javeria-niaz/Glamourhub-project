package com.example.glamourhub.staffmember;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.glamourhub.LoginActivity;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.ChangePasswordService;
import com.example.glamourhub.util.TinyDB;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordActivity extends AppCompatActivity {

    EditText currentPassword, NewPassword, confirmPassword;
    Button btnSubmit;
    ProgressDialog progressDialog;
    TinyDB tinyDB;
    Users users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        tinyDB = new TinyDB(ChangePasswordActivity.this);
        currentPassword = findViewById(R.id.currentPassword);
        NewPassword = findViewById(R.id.NewPassword);
        confirmPassword = findViewById(R.id.confirmPassword);
        btnSubmit = findViewById(R.id.btnSubmit);
        progressDialog = new ProgressDialog(ChangePasswordActivity.this);
        progressDialog.setTitle("please wait...");

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePassword();
            }
        });

    }

    private void updatePassword() {
        users = new Users();
        progressDialog.show();

        RetrofitClient.getClient().create(ChangePasswordService.class).changePass(currentPassword.getText().toString(),
                        NewPassword.getText().toString(), tinyDB.getInt("USER_ID"))
                .enqueue(new Callback<Users>() {
                    @Override
                    public void onResponse(Call<Users> call, Response<Users> response) {
                        if (response.isSuccessful()) {
                            users = response.body();
                            progressDialog.dismiss();
                            if (!users.isError()) {
                                Toast.makeText(ChangePasswordActivity.this,
                                        users.getMessage(), Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                                finishAffinity();
                            } else {
                                Toast.makeText(ChangePasswordActivity.this,
                                        users.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Users> call, Throwable t) {
                        progressDialog.dismiss();
                        Toast.makeText(ChangePasswordActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }
}