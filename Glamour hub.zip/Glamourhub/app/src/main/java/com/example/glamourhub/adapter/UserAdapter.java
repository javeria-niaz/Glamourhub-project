package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class UserAdapter extends BaseAdapter {

    List<Users> usersList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public UserAdapter(List<Users> usersList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.usersList = usersList;
        this.onItemClick= onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return usersList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_user, parent, false);

        TextView UserName = convertView.findViewById(R.id.UserName);
        TextView specialized = convertView.findViewById(R.id.specialized);

        UserName.setText(usersList.get(position).getUser_name());
        specialized.setText(usersList.get(position).getUser_speciality());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }
}
