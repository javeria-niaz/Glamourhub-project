package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.model.Feedback;
import com.example.glamourhub.model.Notification;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class NotificationAdapter extends BaseAdapter {

    List<Notification> notificationList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public NotificationAdapter(List<Notification> notificationList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.notificationList = notificationList;
        this.onItemClick= onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return notificationList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_notification, parent, false);

        TextView notification = convertView.findViewById(R.id.notification);



        notification.setText(notificationList.get(position).getN_title());



        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }
}
