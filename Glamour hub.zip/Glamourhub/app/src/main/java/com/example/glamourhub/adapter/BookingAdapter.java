package com.example.glamourhub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.glamourhub.R;
import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.util.OnItemClick;

import java.util.List;

public class BookingAdapter extends BaseAdapter {
    List<Bookings> bookingsList;
    Context context;
    OnItemClick onItemClick;
    LayoutInflater inflater;

    public BookingAdapter(List<Bookings> bookingsList, Context context, OnItemClick onItemClick) {
        this.context = context;
        this.bookingsList = bookingsList;
        this.onItemClick = onItemClick;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return bookingsList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_bookings, parent, false);

        TextView bookingNumber = convertView.findViewById(R.id.bookingNumber);
        TextView BookingPrice = convertView.findViewById(R.id.BookingPrice);
        TextView BookingDate = convertView.findViewById(R.id.BookingDate);

        bookingNumber.setText("Time: "+bookingsList.get(position).getBooking_time());
        BookingPrice.setText(String.valueOf("Rs. "+bookingsList.get(position).getBooking_total_price()));
        BookingDate.setText("Date: "+bookingsList.get(position).getBooking_date());


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);

            }
        });


        return convertView;
    }


}
