package com.example.glamourhub.services;

import com.example.glamourhub.model.Bookings;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface InsertBookingDetailService {

    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Insert_Booking_Detail_URL)
    Call<Bookings> InsertBookingDetail(
            @Field("fk_booking_id") int fk_booking_id,
            @Field("fk_subservice_id") int fk_subservice_id
    );
}
