package com.example.glamourhub.admin;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.bumptech.glide.Glide;
import com.example.glamourhub.R;
import com.example.glamourhub.model.Subservices;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.DeleteSubService;
import com.example.glamourhub.services.UpdateSubService;
import com.example.glamourhub.services.UpdateSubServiceImage;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.EndPoints;
import com.example.glamourhub.util.TinyDB;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    Button btn_Update, btn_Delete;
    EditText Title, Description, Price, duration;
    ImageView imageView;
    ProgressDialog progressDialog;
    Subservices subservices;
    TinyDB tinyDB;

    Uri imageUri;
    File file;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        progressDialog = new ProgressDialog(ProductDetailActivity.this);
        progressDialog.setMessage("please wait..");
        tinyDB = new TinyDB(ProductDetailActivity.this);

        btn_Update = findViewById(R.id.btn_Update);
        btn_Delete = findViewById(R.id.btn_Delete);
        Title = findViewById(R.id.Title);
        Description = findViewById(R.id.Description);
        Price = findViewById(R.id.Price);
        duration = findViewById(R.id.duration);
        imageView = findViewById(R.id.imageView);


        Title.setText(Constants.subservices.getSs_title());
        Description.setText(Constants.subservices.getSs_description());
        Price.setText(String.valueOf(Constants.subservices.getSs_price()));
        duration.setText(String.valueOf(Constants.subservices.getSs_duration()));
        Glide.with(ProductDetailActivity.this).load(EndPoints.IMAGE_URL + Constants.subservices.getSs_image())
                .into(imageView);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Pick Image"), 1001);

            }
        });

        btn_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteSubService();
            }
        });
        btn_Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateSubService();
            }
        });


    }

    private void updateSubService() {
        progressDialog.show();

        RetrofitClient.getClient().create(UpdateSubService.class)
                .Updatesubservices(Constants.subservices.getSs_id(),
                        Title.getText().toString(),
                        Description.getText().toString(),
                        Integer.parseInt(Price.getText().toString()),
                        duration.getText().toString()).enqueue(new Callback<Subservices>() {
                    @Override
                    public void onResponse(Call<Subservices> call, Response<Subservices> response) {
                        if (response.isSuccessful()) {
                            progressDialog.dismiss();
                            subservices = response.body();
                            if (!subservices.isError()) {
                                Toast.makeText(ProductDetailActivity.this,
                                        subservices.getMessage(), Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), ViewProductActivity.class));
                                finish();
                            } else {
                                Toast.makeText(ProductDetailActivity.this,
                                        subservices.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Subservices> call, Throwable t) {
                        progressDialog.dismiss();
                        Toast.makeText(ProductDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }


    public void DeleteSubService() {
        progressDialog.show();
        subservices = new Subservices();


        RetrofitClient.getClient().create(DeleteSubService.class).DeleteSubService(Constants.subservices.getSs_id()).enqueue(new Callback<Subservices>() {
            @Override
            public void onResponse(Call<Subservices> call, Response<Subservices> response) {
                if (response.isSuccessful()) {
                    subservices = response.body();
                    if (subservices.getCode() == 200) {
                        Toast.makeText(ProductDetailActivity.this, subservices.getMessage(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), ViewProductActivity.class));
                        finish();
                    } else {
                        Toast.makeText(ProductDetailActivity.this, subservices.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Subservices> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(ProductDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 1001) {
            imageView.setImageURI(data.getData());
            imageUri = data.getData();
            updateImageSubService();
        }
    }

    private void updateImageSubService() {
        file = new File(getRealPathFromURI(imageUri));
        //creating request body for file
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
        //creating request body for name
        RequestBody id = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(Constants.subservices.getSs_id()));
        MultipartBody.Part body = MultipartBody.Part.createFormData("filetoupload", file.getName(), requestFile);

        RetrofitClient.getClient().create(UpdateSubServiceImage.class)
                .updateImage(id, body).enqueue(new Callback<Subservices>() {
                    @Override
                    public void onResponse(Call<Subservices> call, Response<Subservices> response) {
                        if (response.code() != 200) {
                            Toast.makeText(ProductDetailActivity.this,
                                    "Something went wrong", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Subservices> call, Throwable t) {
                        Toast.makeText(ProductDetailActivity.this,
                                t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(this, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }


}