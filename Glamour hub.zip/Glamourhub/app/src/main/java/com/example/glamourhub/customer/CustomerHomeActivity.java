package com.example.glamourhub.customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.glamourhub.AboutUsActivity;
import com.example.glamourhub.LoginActivity;
import com.example.glamourhub.R;
import com.example.glamourhub.adapter.CustomerStaffAdapter;
import com.example.glamourhub.adapter.ServiceAdapter;
import com.example.glamourhub.model.Services;
import com.example.glamourhub.model.Users;
import com.example.glamourhub.retrofit.RetrofitClient;
import com.example.glamourhub.services.GetServices;
import com.example.glamourhub.services.GetUserService;
import com.example.glamourhub.util.Constants;
import com.example.glamourhub.util.OnItemClick;
import com.example.glamourhub.util.TinyDB;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerHomeActivity extends AppCompatActivity {

    ImageView cart;
    DrawerLayout customerDrawer;
    NavigationView customerNavView;
    GridView OurServicesLV;
    ImageView drawerMenuIV;
    RecyclerView recyclerView;
    ProgressDialog progressDialog;
    List<Services> servicesList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);
        progressDialog = new ProgressDialog(CustomerHomeActivity.this);
        progressDialog.setMessage("please wait..");
        customerDrawer = findViewById(R.id.customerDrawer);
        drawerMenuIV = findViewById(R.id.drawerMenuIV);
        customerNavView = findViewById(R.id.customerNavView);
        recyclerView = findViewById(R.id.recyclerView);
        OurServicesLV = findViewById(R.id.OurServicesLV);
        cart = findViewById(R.id.cart);
        drawerMenuIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customerDrawer.openDrawer(GravityCompat.START);
            }
        });

        customerNavView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.profileNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(CustomerHomeActivity.this, CustomerProfileActivity.class));
                } else if (item.getItemId() == R.id.bookingNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(CustomerHomeActivity.this, BookingHistoryActivity.class));
                } else if (item.getItemId() == R.id.notificationNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(CustomerHomeActivity.this, NotificationActivity.class));
                } else if (item.getItemId() == R.id.aboutUsNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(CustomerHomeActivity.this, AboutUsActivity.class));
                } else if (item.getItemId() == R.id.feedbackNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    startActivity(new Intent(CustomerHomeActivity.this, FeedbackActivity.class));
                } else if (item.getItemId() == R.id.logoutNav) {
                    customerDrawer.closeDrawer(GravityCompat.START);
                    new TinyDB(CustomerHomeActivity.this).clear();
                    startActivity(new Intent(CustomerHomeActivity.this, LoginActivity.class));
                    finishAffinity();
                }
                return true;
            }
        });


        getStaffData();

     /*   CardView makeup= findViewById(R.id.makeup);
        makeup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CustomerHomeActivity.this, CustomerServiceDetailActivity.class));
            }
        });*/

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CustomerHomeActivity.this, CartActivity.class));
                finishAffinity();
            }
        });


        getServiceData();

    }

    private void getServiceData() {
        progressDialog.show();
        servicesList.clear();
        RetrofitClient.getClient().create(GetServices.class).getservices().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {
                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);

                                servicesList.add(new Services(
                                        data.getInt("service_id"),
                                        data.getString("service_title"),
                                        data.getString("service_image"),
                                        data.getString("service_status")
                                ));

                            }

                            ServiceAdapter adapter = new ServiceAdapter(servicesList,
                                    CustomerHomeActivity.this, new OnItemClick() {
                                @Override
                                public void onClick(int pos) {
                                    Constants.services = servicesList.get(pos);
                                    startActivity(new Intent(getApplicationContext(), CustomerServiceDetailActivity.class));

                                }
                            });
                            OurServicesLV.setAdapter(adapter);


                        } catch (Exception exception) {
                            Toast.makeText(CustomerHomeActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(CustomerHomeActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(CustomerHomeActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    List<Users> usersList = new ArrayList<>();


    private void getStaffData() {
        progressDialog.show();
        usersList.clear();

        RetrofitClient.getClient().create(GetUserService.class).getusers().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    if (response.code() == 200) {

                        try {
                            JSONObject jsonobject = new JSONObject(response.body().getAsJsonObject().toString());
                            JSONArray jsonArray = jsonobject.getJSONArray("records");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = jsonArray.getJSONObject(i);
                                if (data.getString("user_type").equals("SM")) {
                                    usersList.add(new Users(
                                            data.getInt("user_id"),
                                            data.getString("user_name"),
                                            data.getString("user_email"),
                                            data.getString("user_cnic"),
                                            data.getString("user_contact"),
                                            data.getString("user_status"),
                                            data.getString("user_type"),
                                            data.getString("user_createdDateTime"),
                                            data.getString("user_speciality"),
                                            data.getString("user_address")
                                    ));
                                }
                            }
                            CustomerStaffAdapter adapter = new CustomerStaffAdapter(CustomerHomeActivity.this, usersList);
                            recyclerView.setAdapter(adapter);

                        } catch (Exception exception) {
                            Toast.makeText(CustomerHomeActivity.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else {
                        Toast.makeText(CustomerHomeActivity.this, "Record Not Found..Network Error", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                progressDialog.dismiss();
                Toast.makeText(CustomerHomeActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void setData() {

    }
}