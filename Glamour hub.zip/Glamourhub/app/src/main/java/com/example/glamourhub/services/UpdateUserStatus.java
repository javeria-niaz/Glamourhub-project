package com.example.glamourhub.services;

import com.example.glamourhub.model.Users;
import com.example.glamourhub.util.EndPoints;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface UpdateUserStatus {

    @Headers("Accept: application/json")
    @FormUrlEncoded
    @POST(EndPoints.Update_User_Status_URL)
    Call<Users> UpdateStatus(
            @Field("user_id") int user_id,
            @Field("user_status") String user_status
    );
}
