<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['ss_id']) 
    && isset($_POST['ss_title'])
    && isset($_POST['ss_description'])
    && isset($_POST['ss_price'])
    && isset($_POST['ss_duration'])) {
        $sql = "UPDATE tbl_sub_services SET ss_title = ?, ss_description = ?, ss_price = ?,  ss_duration = ?   WHERE ss_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('ssisi', 
         $_POST['ss_title'],
         $_POST['ss_description'],
         $_POST['ss_price'],
         $_POST['ss_duration'],
         $_POST['ss_id']);


        if ($stmt->execute()) {
            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = "Record Updated Successfully";
        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = "Failed To Update Record";
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Required field is missing";
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

