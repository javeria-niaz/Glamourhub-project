<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();
$userID=0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['booking_id']) && isset($_POST['booking_status'])) {
        $sql = "UPDATE tbl_booking SET booking_status = ? WHERE booking_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('si', $_POST['booking_status'], $_POST['booking_id']);

        if ($stmt->execute()) {
            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = "Record Updated Successfully";

            $sql2 = "SELECT fk_user_id FROM `tbl_booking` WHERE booking_id=?";
            $stmt2 = $con->prepare($sql2);
            $stmt2->bind_param('i',$_POST['booking_id']);
            $stmt2->execute();
            $stmt2->store_result();
            $rows = $stmt2->num_rows;
            $stmt2->bind_result($user_id);
            while ($stmt2->fetch()) {
                $userID= $user_id;
            }

            if($_POST['booking_status']=='CMP'){
                $title="Booking Complete Your Booking";
                $nFor='C';
                $nType='booking';
                $sql3 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
                $stmt3 = $con->prepare($sql3);
                $stmt3->bind_param('ssis',$title,$nFor,$userID,$nType);
                $stmt3->execute();
            }else if($_POST['booking_status']=='C'){
                $title="Customer Cancel their Booking";
                $nFor='A';
                $nForID=7;
                $nType='booking';
                $sql3 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
                $stmt3 = $con->prepare($sql3);
                $stmt3->bind_param('ssis',$title,$nFor,$nForID,$nType);
                $stmt3->execute();
            }




        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = "Failed To Update Record";
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Required field is missing";
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

