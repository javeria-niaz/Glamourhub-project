<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';

$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT booking_id,booking_date,booking_time,fk_user_id,booking_status,booking_total_price,tbl_booking_detail.fk_staff_id FROM `tbl_booking`
JOIN tbl_booking_detail ON tbl_booking_detail.fk_booking_id=tbl_booking.booking_id";
    $stmt = $con->prepare($query);
    $stmt->execute();
    $stmt->store_result();
    $row = $stmt->num_rows() > 0;
    if ($row == 1) {
        $stmt->bind_result(
            $booking_id,$booking_date,$booking_time,$fk_user_id,$booking_status,$booking_total_price, $fk_staff_id
        );
        while ($row = $stmt->fetch()) {
            $data = array(
                'booking_id' => $booking_id,
                'booking_date' => $booking_date,
                'booking_date' => $booking_date,
                'booking_time'=> $booking_time,
                'fk_user_id' => $fk_user_id,
                'booking_status'=> $booking_status,
                'booking_total_price' => $booking_total_price,
                'fk_staff_id' => $fk_staff_id
                
            );
            array_push($resultSet, $data);
        }
        $response['error'] = false;
        $response['code'] = 200;
        $response['message'] = "record found";
        $response['records']   = $resultSet;
    } else if ($row == 0) {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Record not found";
    }

}else{

    $response['code']= 500;
    $response['error']= true;
    $response['message']= "Invalid Request Method";

}

echo json_encode($response);