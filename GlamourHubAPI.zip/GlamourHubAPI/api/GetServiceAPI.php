<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';

$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT service_id,service_title,service_image,service_status FROM `tbl_service`";
    $stmt = $con->prepare($query);
    $stmt->execute();
    $stmt->store_result();
    $row = $stmt->num_rows() > 0;
    if ($row == 1) {
        $stmt->bind_result(
            $service_id,$service_title,$service_image,$service_status
        );
        while ($row = $stmt->fetch()) {
            $data = array(
                'service_id' => $service_id,
                'service_title' => $service_title,
                'service_image'=> $service_image,
                'service_status' => $service_status
                
            );
            array_push($resultSet, $data);
        }
        $response['error'] = false;
        $response['code'] = 200;
        $response['message'] = "record found";
        $response['records']   = $resultSet;
    } else if ($row == 0) {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Record not found";
    }

}else{

    $response['code']= 500;
    $response['error']= true;
    $response['message']= "Invalid Request Method";

}

echo json_encode($response);