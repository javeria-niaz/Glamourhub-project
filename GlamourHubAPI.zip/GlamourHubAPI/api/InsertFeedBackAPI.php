<?php
header("Content-Type: application/json; charset=UTF-8");

include_once '../include/DbConnect.php';
include_once '../operations/DbOperations.php';

$response = array();
$db = new DbConnect();
$con = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['feedback_title'])
        && isset($_POST['user_id'])
        && isset($_POST['rating'])
       
    ) {
        $db = new DbOperations();
        $result = $db->InsertFeedback(
            $_POST['feedback_title'],
            $_POST['user_id'],
            $_POST['rating']
        );

        if ($result == 0) {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Feedback Already Exist';
        } else if ($result == 1) {
            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = 'Feedback Submitted Successfully';
        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Feedback Not Submitted';
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = 'Required Field Missing';
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

