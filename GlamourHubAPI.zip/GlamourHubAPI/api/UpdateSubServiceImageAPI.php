<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();

$target_dir = $_SERVER['DOCUMENT_ROOT']. '/GlamourHubAPI/image/';


if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    if(isset($_POST['ss_id']) 
    && $_FILES['filetoupload']['name'] != "")
    
    {
        $db = new DbOperations();

        $image_name = basename($_FILES["filetoupload"]["name"]);
        $target_file= $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        if(move_uploaded_file($_FILES["filetoupload"]["tmp_name"],$target_file))
        {

            $sql="UPDATE tbl_sub_services SET ss_image=? WHERE ss_id =?";
            $stmt=$con->prepare($sql);
            $stmt->bind_param('si',$image_name,$_POST['ss_id']);
            $stmt->execute();

            $response['error']=false;
            $response['code']=200;
            $response['message']="Service updated Successfully";

    }

}   else{
    $response['code']=true;
    $response['error']=404;
    $response['message']="Required field is missing" ;  }
}else{
    $response['error']=true;
    $response['code']=500;
    $response['message']='Invalid Request Method';
}
echo json_encode($response);