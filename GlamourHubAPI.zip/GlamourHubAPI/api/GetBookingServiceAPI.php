<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';

$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT bd_id,fk_booking_id,fk_subservice_id,fk_staff_id,tbl_sub_services.ss_id,tbl_sub_services.ss_title,
    tbl_sub_services.ss_image,tbl_sub_services.ss_price,tbl_service.service_id,tbl_service.service_title FROM `tbl_booking_detail` JOIN tbl_sub_services ON tbl_sub_services.ss_id=tbl_booking_detail.fk_subservice_id JOIN tbl_service ON tbl_service.service_id=tbl_sub_services.fk_service_id";
    $stmt = $con->prepare($query);
    $stmt->execute();
    $stmt->store_result();
    $row = $stmt->num_rows() > 0;
    if ($row == 1) {
        $stmt->bind_result(
            $bd_id,$fk_booking_id,$fk_subservice_id,$fk_staff_id,$ss_id,$ss_title, $ss_image, $ss_price, $service_id, $service_title
        );
        while ($row = $stmt->fetch()) {
            $data = array(
                'bd_id' => $bd_id,
                'fk_booking_id' => $fk_booking_id,
                'fk_subservice_id'=> $fk_subservice_id,
                'fk_staff_id' => $fk_staff_id,
                'ss_id' => $ss_id,
                'ss_title' => $ss_title,
                'ss_image' => $ss_image,
                'ss_price' => $ss_price,
                'service_id' => $service_id,
                'service_title' => $service_title
                
            );
            array_push($resultSet, $data);
        }
        $response['error'] = false;
        $response['code'] = 200;
        $response['message'] = "record found";
        $response['records']   = $resultSet;
    } else if ($row == 0) {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Record not found";
    }

}else{

    $response['code']= 500;
    $response['error']= true;
    $response['message']= "Invalid Request Method";

}

echo json_encode($response);