<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();

$target_dir = $_SERVER['DOCUMENT_ROOT']. '/GlamourHubAPI/image/';


if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    if(isset($_POST['ss_title']) 
    && isset($_POST['ss_description']) 
    && isset($_POST['ss_price'])
    && isset($_POST['ss_duration'])
    && $_FILES['filetoupload']['name'] != ""
    && isset($_POST['fk_service_id']))
    
    {
        $db = new DbOperations();

        $image_name = basename($_FILES["filetoupload"]["name"]);
        $target_file= $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        if(move_uploaded_file($_FILES["filetoupload"]["tmp_name"],$target_file))
        {

        $result= $db->insertSubservice(
            $_POST['ss_title'],
            $_POST['ss_description'],
            $_POST['ss_price'],
            $_POST['ss_duration'],
            $image_name,
        $_POST['fk_service_id']);
        
            if($result==1){
                $response['error']=false;
                $response['code']=200;
                $response['message']="Service Inserted Successfully";
               }else{
                $response['error']=true;
                $response['code']=404;
                $response['message']="Service Not Inserted ";
               }
        

    }

}   else{
    $response['code']=true;
    $response['error']=404;
    $response['message']="Required field is missing" ;  }
}else{
    $response['error']=true;
    $response['code']=500;
    $response['message']='Invalid Request Method';
}
echo json_encode($response);