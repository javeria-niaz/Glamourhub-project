<?php
header("Content-Type: application/json; charset=UTF-8");

include_once '../include/DbConnect.php';
include_once '../operations/DbOperations.php';

$response = array();
$db = new DbConnect();
$con = $db->connect();
$bookingID=0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['booking_date'])
        && isset($_POST['booking_time'])
        && isset($_POST['fk_user_id'])
        && isset($_POST['booking_total_price'])
    ) {
        $db = new DbOperations();
        $result = $db->InsertBooking(
            $_POST['booking_date'],
            $_POST['booking_time'],
            $_POST['fk_user_id'],
            $_POST['booking_total_price']
           
        );

        if ($result == 0) {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Booking Already Exists';
        } else if ($result == 1) {
            $sql = "SELECT booking_id FROM `tbl_booking` ORDER BY booking_id DESC LIMIT 1";
            $stmt = $con->prepare($sql);
            $stmt->execute();
            $stmt->store_result();
            $rows = $stmt->num_rows;
            $stmt->bind_result($booking_id);
            while ($stmt->fetch()) {
                $response['booking_id'] = $booking_id;
                $bookingID= $booking_id;
            }

            $title="New Booking Request Recieved";
            $nFor='A';
            $nForID=7;
            $nType='booking';
            $sql1 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
            $stmt1 = $con->prepare($sql1);
            $stmt1->bind_param('ssis',$title,$nFor,$nForID,$nType);
            $stmt1->execute();


            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = 'Booking Added Successfully';



        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Booking Not Added';
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = 'Required Field Missing';
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

