<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['user_id'])) {

        $sql = "DELETE FROM tbl_user WHERE user_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $_POST['user_id']);
        if ($stmt->execute()) {
            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = "Record Deleted Successfully";
        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = "Failed To Update Record";
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Required field is missing";
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

