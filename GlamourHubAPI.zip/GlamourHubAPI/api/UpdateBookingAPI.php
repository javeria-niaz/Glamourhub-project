<?php
header("Content-Type: application/json; charset=UTF-8");
include_once '../operations/DbOperations.php';
include_once '../include/DbConnect.php';
$db = new DbConnect();
$con = $db->connect();
$data = array();
$response = array();
$resultSet = array();
$userID=0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['fk_booking_id']) 
        && isset($_POST['fk_staff_id'])
        && isset($_POST['fk_subservice_id'])
        && isset($_POST['booking_status'])
    ) {
        $status='A';
        $sql = "UPDATE tbl_booking_detail SET fk_staff_id = ? WHERE fk_booking_id = ? AND fk_subservice_id=?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $_POST['fk_staff_id'], $_POST['fk_booking_id'], $_POST['fk_subservice_id']);

        $stmt->execute();
        $sql1 = "UPDATE tbl_booking SET booking_status = ? WHERE booking_id= ?";
        $stmt1 = $con->prepare($sql1);
        $stmt1->bind_param('si', $status, $_POST['fk_booking_id']);
        $stmt1->execute();

        $title="New Booking Assigned To You";
        $nFor='S';
        $nType='booking';
            $sql2 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
            $stmt2 = $con->prepare($sql2);
            $stmt2->bind_param('ssis',$title,$nFor,$_POST['fk_staff_id'],$nType);
            $stmt2->execute();

            $sql5 = "SELECT fk_user_id FROM `tbl_booking` WHERE booking_id=?";
            $stmt5 = $con->prepare($sql5);
            $stmt5->bind_param('i',$_POST['fk_booking_id']);
            $stmt5->execute();
            $stmt5->store_result();
            $rows = $stmt5->num_rows;
            $stmt5->bind_result($user_id);
            while ($stmt5->fetch()) {
                $userID= $user_id;
            }

            if($_POST['booking_status']=='A'){
                $title="Saloon Accepted Your Booking";
                $nFor='C';
                $nType='booking';
                $sql3 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
                $stmt3 = $con->prepare($sql3);
                $stmt3->bind_param('ssis',$title,$nFor,$userID,$nType);
                $stmt3->execute();
            }else if($_POST['booking_status']=='R'){
                $title="Saloon Rejected Your Booking";
                $nFor='C';
                $nType='booking';
                $sql3 = "INSERT INTO tbl_notifications(n_title,n_for,n_for_id,n_type) VALUES (?,?,?,?)";
                $stmt3 = $con->prepare($sql3);
                $stmt3->bind_param('ssis',$title,$nFor,$userID,$nType);
                $stmt3->execute();
            }


        $response['error'] = false;
        $response['code'] = 200;
        $response['message'] = "Record Updated Successfully";
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = "Required field is missing";
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

