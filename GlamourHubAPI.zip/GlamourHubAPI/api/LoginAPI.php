<?php
header("Content-Type: application/json; charset=UTF-8");

include_once '../include/DbConnect.php';
include_once '../operations/DbOperations.php';

$response = array();
$db = new DbConnect();
$con = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['user_email']) && isset($_POST['user_password'])) {

        $db = new DbOperations();
        $result = $db->Loginuser(
            $_POST['user_email'],
            $_POST['user_password']
        );

        if ($result) {
            $sql = "SELECT user_id, user_name, user_email, user_cnic, user_contact, user_status, user_type, user_speciality
                    FROM `tbl_user` WHERE user_email = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('s', $_POST['user_email']);
            $stmt->execute();
            $stmt->store_result();
            $rows = $stmt->num_rows;

            if ($rows == 1) {
                $stmt->bind_result(
                    $user_id, $user_name, $user_email, $user_cnic, $user_contact, $user_status, $user_type, $user_speciality
                );
                while ($stmt->fetch()) {
                    $response['user_id'] = $user_id;
                    $response['user_name'] = $user_name;
                    $response['user_email'] = $user_email;
                    $response['user_cnic'] = $user_cnic;
                    $response['user_contact'] = $user_contact;
                    $response['user_status'] = $user_status;
                    $response['user_type'] = $user_type;
                    $response['user_speciality'] = $user_speciality;
                }
            }

            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = 'Login Successful';
        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Login Failed';
        }
    } else {
        $response['error'] = true;
        $response['code'] = 500;
        $response['message'] = 'Missing Parameters';
    }
} else {
    $response['error'] = true;
    $response['code'] = 405;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

