<?php
header("Content-Type: application/json; charset=UTF-8");

include_once '../include/DbConnect.php';
include_once '../operations/DbOperations.php';

$response = array();
$db = new DbConnect();
$con = $db->connect();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['user_name'])
        && isset($_POST['user_email'])
        && isset($_POST['user_password'])
        && isset($_POST['user_cnic'])
        && isset($_POST['user_contact'])
        && isset($_POST['user_status'])
        && isset($_POST['user_type'])
        && isset($_POST['user_speciality'])
        && isset($_POST['user_address'])
        
    ) {
        $db = new DbOperations();
        $result = $db->InsertStaffMember(
            $_POST['user_name'],
            $_POST['user_email'],
            $_POST['user_password'],
            $_POST['user_cnic'],
            $_POST['user_contact'],
            $_POST['user_status'],
            $_POST['user_type'],
            $_POST['user_speciality'],
            $_POST['user_address']
        );

        if ($result == 0) {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Email Already Exists';
        } else if ($result == 1) {
            $response['error'] = false;
            $response['code'] = 200;
            $response['message'] = 'Account Created Successfully';
        } else {
            $response['error'] = true;
            $response['code'] = 404;
            $response['message'] = 'Account Not Created';
        }
    } else {
        $response['error'] = true;
        $response['code'] = 404;
        $response['message'] = 'Required Field Missing';
    }
} else {
    $response['error'] = true;
    $response['code'] = 500;
    $response['message'] = 'Invalid Request Method';
}

echo json_encode($response);

