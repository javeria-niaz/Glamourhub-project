case 'uploadpostimage':
    $target_dir = $_SERVER['DOCUMENT ROOT'].'/tODOLIST_COREPHP/IMAGE/';
    IF($_FILES['filetoupload']['name'] != ""){
        $image_name = basename($_FILES["filetoupload"]["name"]);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        if($imageFileType ="jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"){
            $res['data'] = array();
            $res['message'] = "Sorry, only JPG, JPEG, PNG and GIF files are allowed.";
            $res['status'] = 'fail';
        }else{
            if( move_uploaded_file($_FILES["filetoupload"]["tmp_name"], $target_file)) {
                $qry2 = mysqli_query($conn,'INSERT into image (id,name) VALUES ("","'.$image_name.'")');
                $res['data']['image'] = $image_name;
                $res['status'] = 'success';
                $res['message'] = 'Base64 image uploade';     
            }else{
                $res['data'] = array();
                $res['message'] = "Sorry, there was an error uploading your file.";
                $res['status'] = 'fail';
            }
        }
    }else{
        $res['data'] = array();
        $res['status'] = 'fail';
        $res['message'] = 'Please Pass image';
    }
    break;