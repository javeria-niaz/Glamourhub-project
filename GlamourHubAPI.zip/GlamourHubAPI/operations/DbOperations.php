<?php

class DbOperations
{
    function __construct()
    {
        require_once '../include/DbConnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();
    }

    public function CreateCustomerAccount($name, $email, $password, $cnic, $contact, $status, $type)
    {
        $c_pass = md5($password); 
        if ($this->CheckCustomerEmail($email)) {
            return 0;
        } else {
            $sql = "INSERT INTO tbl_user (user_name, user_email, user_password, user_cnic, user_contact, user_status, user_type) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $this->con->prepare($sql);
            $stmt->bind_param('sssssss', $name, $email, $c_pass, $cnic, $contact, $status, $type);
            if ($stmt->execute()) {
                return 1;
            } else {
                return 2;
            }
        }
    }

    public function insertservice($service_title,$service_image)  {
        $sql = "INSERT INTO tbl_service (service_title, service_image) 
        VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('ss', $service_title, $service_image);
        if ($stmt->execute()) {
            return 1;
        } else {
            return 2;
        }

    }

    public function Loginuser( $user_email, $user_password)
    {
        $c_pass = md5($user_password); 
        $sql="SELECT * From tbl_user WHERE user_email=? AND user_password=?";
        $stmt=$this->con->prepare($sql);
        $stmt->bind_param('ss', $user_email, $c_pass);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows>0;
    }


    public function CheckCustomerEmail($email)
    {
        
        $sql = "SELECT * FROM tbl_user WHERE user_email = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }

    public function InsertStaffMember($name, $email, $password, $cnic, $contact, $status, $type, $speciality, $user_address)
    {
        $c_pass = md5($password); 
        if ($this->CheckCustomerEmail($email)) {
            return 0;
        } else {
            $sql = "INSERT INTO tbl_user (user_name, user_email, user_password, user_cnic, user_contact, user_status, user_type,
             user_speciality, user_address) 
                    VALUES (?, ?, ?, ?, ?, ?,?, ?, ?)";
            $stmt = $this->con->prepare($sql);
            $stmt->bind_param('sssssssss', $name, $email, $c_pass, $cnic, $contact, $status, $type, $speciality, $user_address);
            if ($stmt->execute()) {
                return 1;
            } else {
                return 2;
            }
        }
    }

    public function insertSubservice($ss_title, $ss_description, $ss_price, $ss_duration, $ss_image, $fk_service_id)  {
        $sql = "INSERT INTO tbl_sub_services (ss_title, ss_description, ss_price, ss_duration, ss_image,fk_service_id) 
        VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('sssssi', $ss_title, $ss_description, $ss_price, $ss_duration, $ss_image, $fk_service_id);
        if ($stmt->execute()) {
            return 1;
        } else {
            return 2;
        }

    }

    public function InsertBooking($booking_date, $booking_time, $fk_user_id, $booking_total_price)
    {
        $sql = "INSERT INTO tbl_booking (booking_date, booking_time, fk_user_id, booking_total_price) 
                VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('ssii', $booking_date, $booking_time, $fk_user_id, $booking_total_price);
        if ($stmt->execute()) {
            return 1;
        } else {
            return 2;
        }
    }

    public function InsertBookingDetail($fk_booking_id, $fk_subservice_id)
    {
        $sql = "INSERT INTO tbl_booking_detail (fk_booking_id, fk_subservice_id) 
                VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('ii', $fk_booking_id, $fk_subservice_id);
        if ($stmt->execute()) {
            return 1;
        } else {
            return 2;
        }
    }

    
    public function CheckUserPassword($password, $id)
    {
        $pass = md5($password);
        $query = "SELECT * FROM tbl_user WHERE user_password = ? AND user_id=?";
        $stmt = $this->con->prepare($query);
        $stmt->bind_param("si", $pass, $id);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }


    public function InsertFeedback($feedback_title,$user_id,$rating)
    {
        $sql = "INSERT INTO tbl_feedback (feedback_title,user_id,rating) 
                VALUES (?, ?,?)";
        $stmt = $this->con->prepare($sql);
        $stmt->bind_param('sis',$feedback_title,$user_id,$rating);
        if ($stmt->execute()) {
            return 1;
        } else {
            return 2;
        }
    }
}


